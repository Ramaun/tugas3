package com.example.tugas3;

public class GameModel {
    private String namaGame;
    private int logoGame;

    public String getNamaGame() {
        return namaGame;
    }

    public void setNamaGame(String namaGame) {
        this.namaGame = namaGame;
    }

    public int getLogoGame() {
        return logoGame;
    }

    public void setLogoGame(int logoGame) {
        this.logoGame = logoGame;
    }
}


